class SingletonMeta(type):
    """Singleton class

    Metaclass to provide Singleton pattern
    to custom Python class.

    """
    _instance = None

    def __call__(cls):
        if cls._instance is None:
            print(type(super()))
            cls._instance = super().__call__()
        return cls._instance

