class NVector:
    def __init__(self, rank=None, array=None, string=None):
        """NVector constructor

        Raise:
            TypeError: if rank is not integer.

        Args:
            rank (int): set rank of constructed NVector.
            array (list): list of float values to construct NVector.
            string (str): string of float values in format ('value1 value2 ...').
        """
        if rank is not None:
            if isinstance(rank, int):
                self.rank = rank
                self.vector = (0 for i in range(rank))
            else:
                raise TypeError('Rank must be integer')

        elif array is not None:
            if isinstance(array, list):
                self.vector = list()
                self.rank = 0
                for num in array:
                    if isinstance(num, float) or isinstance(num, int):
                        self.vector.append(float(num))
                        self.rank += 1
                    else:
                        raise TypeError('Array must be from floats')
            else:
                raise TypeError('Array must be list')

        elif string is not None:
            if isinstance(string, str):
                self.vector = list()
                self.rank = 0
                for num in string.split():
                    self.vector.append(float(num))
                    self.rank += 1
            else:
                raise TypeError('Rank must be integer')

    def add(self, other):
        """Add other NVector

        Vector summation of this object and other NVector.

        Raise:
            NVectorError: if other rank is not equal current object rank.

        Args:
            other (NVector): second component of vector summation.

        Returns:
            new_vector (NVector): result of vector summation.
        """
        if self.rank != other.rank:
            raise NVectorError
        else:
            new_vector = list()
            for xi, yi in zip(other, self):
                new_vector.append(xi + yi)
            return NVector(array=new_vector)

    def sub(self, other):
        """Subtract other NVector

        Vector subtraction of this object and other NVector.

        Raise:
            NVectorError: if other rank is not equal current object rank.

        Args:
            other (NVector): second component of vector subtraction.

        Returns:
            new_vector (NVector): result of vector subtraction.
        """
        if self.rank != other.rank:
            raise NVectorError
        else:
            new_vector = list()
            for xi, yi in zip(self, other):
                new_vector.append(xi - yi)
            return NVector(array=new_vector)

    def mul(self, scalar):
        """Multiplication this NVector on scalar

        Vector scalar multiplication of this object and scalar.

        Args:
            scalar (int): scalar to multiply.

        Returns:
            new_vector (NVector): result of vector scalar multiplication.
        """
        new_vector = list()
        for xi in self:
            new_vector.append(xi * scalar)
        return NVector(array=new_vector)

    def div(self, scalar):
        """Division this NVector on scalar.

            Vector scalar division of this object and scalar.

        Args:
            scalar (int): scalar to divide.

        Returns:
            new_vector (NVector): result of vector scalar multiplication.

        Raises:
            ZeroDivisionError: error in case scalar = 0.
        """
        if scalar == 0.0:
            raise ZeroDivisionError
        else:
            new_vector = list()
            for xi in self:
                new_vector.append(xi / scalar)
            return NVector(array=new_vector)

    def matmul(self, other):
        """Vector dot product

        Compute dot product of current object and other NVector.

        Raise:
            NVectorError: if other rank is not equal current object rank.

        Args:
            other (NVector): second component of dot product.

        Returns:
            dot_product (int): result of vector dot product.
        """
        if self.rank != other.rank:
            raise NVectorError
        else:
            dot_product = 0.0
            for xi, yi in zip(other, self):
                dot_product += xi * yi
            return dot_product

    def equal(self, other):
        """Vector comparision

        Compare object NVector elements to other NVector elements. Return
        True if all elements of other NVector is respectively equal, otherwise
        False.

        Raise:
            NVectorError: if other rank is not equal current object rank.

        Args:
            other (NVector): NVector to compare.

        Returns:
            result (bool): result of comparison.
        """
        if self.rank != other.rank:
            raise NVectorError
        else:
            for xi, yi in zip(self, other):
                if xi != yi:
                    return False
            return True

    def norm(self):
        """Norm of vector

        Return euclidean norm.

        Returns:
            result (float): norm of vector.
        """
        norm = 0.0
        for xi in self.vector:
            norm += xi ** 2
        return norm ** 0.5

    def __len__(self):
        """Rank of vector

        Return vector rank.

        Returns:
            rank (float): vector rank.
        """
        return self.rank

    def __str__(self):
        """String representation of vector

        Return string representation of vector.

        Returns:
            string_vector (str): vector string.
        """
        return ', '.join(str(i) for i in self.vector)

    def __repr__(self):
        """Representation of vector

        Return representation of vector.

        Returns:
            vector (str): vector string.
        """
        string_vector = '['
        for xi in self:
            string_vector += '{}, '.format(xi)
        string_vector = string_vector[:-2]
        string_vector += ']'

        return string_vector

    def __getitem__(self, item):
        """
        Args:
            item:
        """
        return self.vector[item]

    def __setitem__(self, key, value):
        self.vector[key] = value

    def __add__(self, other):
        return self.add(other)

    def __iadd__(self, other):
        self.vector = self.add(other).vector
        return self

    def __sub__(self, other):
        return self.sub(other)

    def __isub__(self, other):
        self.vector = self.sub(other).vector
        return self

    def __mul__(self, scalar):
        return self.mul(scalar)

    def __imul__(self, scalar):
        self.vector = self.mul(scalar).vector
        return self

    def __truediv__(self, scalar):
        return self.div(scalar)

    def __idiv__(self, scalar):
        self.vector = self.div(scalar).vector
        return self

    def __matmul__(self, other):
        return self.matmul(other)

    def __eq__(self, other):
        return self.equal(other)

    def __ne__(self, other):
        return ~self.equal(other)

    def __abs__(self):
        return self.norm()

    def __iter__(self):
        return self.vector.__iter__()


class NVectorError(Exception):
    """Class to represent NVector error

        NVectorError represents error occurred during operations
        with NVector.

        Attributes:
            message(str): represents error message.
    """
    def __init__(self, message='Error'):
        """NVectorError constructor

        Args:
            message(str): error message.
        """
        self.message = message