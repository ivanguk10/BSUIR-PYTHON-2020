from warnings import warn
from collections.abc import Hashable


def __hash_arguments(args: tuple, kwargs: dict):
    """Hash arguments

    Hash all function non-keyable and keyable arguments of function.

    Args:
        args(tuple): non-keyable arguments
        kwargs(dict): keyable arguments

    Returns:
        hash_value(int): hash of function's arguments
    """
    hash_value = 0
    for value in args:
        if not isinstance(value, Hashable):
            warn("Unhashable object {} of type {}".format(value, type(value)), RuntimeWarning)
            hash_value += hash(str(value))
        else:
            hash_value += hash(value)

    for key in sorted(kwargs.keys()):
        if not isinstance(kwargs[key], Hashable):
            warn("Unhashable object {} of type {}".format(kwargs[key], type(kwargs[key])), RuntimeWarning)

            hash_value += hash(key)
            hash_value += hash(str(kwargs[key]))
        else:
            hash_value += hash(str(key))
            hash_value += hash(kwargs[key])

    return hash_value


def cached(func):
    """Decorator for function's memoization

    Return value of function. If function with current arguments was invoked
    before, than returned cached value. Otherwise compute value of function.

    Args:
        func: function to decorate

    Returns:
        cached_function: decorated function

    Warning:
        RuntimeWarning: warning using of unhashable types
    """
    values = dict()
    doc_string = func.__doc__

    def cache_function(*args, **kwargs):
        string = __hash_arguments(args, kwargs)
        if string in values.keys():
            return values[string]
        else:
            value = func(*args, **kwargs)
            values[string] = value
            return value

    cache_function.__doc__ = doc_string
    return cache_function
