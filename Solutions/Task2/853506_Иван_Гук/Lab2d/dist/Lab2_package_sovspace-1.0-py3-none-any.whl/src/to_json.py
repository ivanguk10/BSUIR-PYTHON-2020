def __list_tuple_to_json(obj, level):
    """Serialize list or tuple to JSON

        Serialize Python list or tuple to JSON-string dictionary according
        to current recursion level.

    Args:
        obj (list, tuple): list or tuple to serialize.
        level (int): level of recursion.
    Returns:
        string(str): JSON-string representation of list or tuple.
    """
    string = '[\n'
    for element in obj[:-1]:
        string += '\t' * level + __value_to_json(element, level + 1) + ',\n'

    string += '\t' * level + __value_to_json(obj[-1], level + 1)
    string += ']'

    return string


def __dict_to_json(obj: dict, level):
    """Serialize dictionary to JSON

    Serialize Python dictionary to JSON-string dictionary according
    to current recursion level.

    Args:
        obj (dict): dictionary to serialize.
        level (int): level of recursion.
    """
    string = '{\n'
    for key, value in list(obj.items())[:-1]:
        string += '\t' * level + '"{}": '.format(str(key)) + __value_to_json(value, level + 1) + ",\n"

    last_key, last_value = list(obj.items())[-1]

    string += '\t' * level + '"{}": '.format(str(last_key)) + __value_to_json(last_value, level + 1)
    string += '}'

    return string


def __value_to_json(value, level):
    """Serialize object to JSON value

    Serialize Python object to JSON-string value representation according
    to current level of recursion.

    Args:
        value (obj): object to serialize.
        level (int): level of recursion.

    Return:
        string (str): JSON-string representation of value.
    """
    string = ''

    if isinstance(value, dict):
        string = __dict_to_json(value, level)

    elif isinstance(value, list) or isinstance(value, tuple):
        string = __list_tuple_to_json(value, level)

    elif isinstance(value, bool):
        string = 'true' if value else 'false'

    elif isinstance(value, int) or isinstance(value, float) or isinstance(value, complex):
        string = str(value)

    elif isinstance(value, str):
        string = '"{}"'.format(str(value))

    elif value is None:
        string = 'null'

    else:
        string += __object_to_json(value, level)

    return string


def __object_to_json(obj: object, level):
    """Auxiliary function serialize Python object to JSON

    Serialize Python object to JSON-string object representation according
    to current level of recursion.

    Args:
        obj (obj): object to serialize.
        level (int): level of recursion.

    Return:
        string (str): JSON-string representation of object.
    """
    json_string = '{\n'

    if isinstance(obj, dict):
        iterable_dict = obj
    else:
        iterable_dict = vars(obj)

    for key, value in list(iterable_dict.items())[:-1]:
        json_string += '\t' * level + '"{}": {}'.format(str(key), __value_to_json(value, level + 1)) + ',\n'

    last_key, last_value = list(iterable_dict.items())[-1]
    json_string += '\t' * level + '"{}": {}'.format(str(last_key), __value_to_json(last_value, level + 1))

    json_string += '}'
    return json_string


def to_json(obj: object):
    """Serializes Python object to JSON

    Serialize Python object with __dict__ attribute into JSON string.

    Args:
        obj (object): serializable object.

    Raises:
        TypeError: if object doesn't have __dict__ attribute.

    Return:
        json_string (str): JSON representation of object.
    """
    return __object_to_json(obj, 0)
