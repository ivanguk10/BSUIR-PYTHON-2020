Description
===========
Installable project of the 2'nd ISP lab